var app = angular.module('StarterApp', ['ngMaterial']); 

app.controller('AppCtrl', ['$scope', function($scope){
  $scope.toggleSearch = false;
  $scope.headers = [
    {
      name:'',
      field:'thumb'
    },{
      name: 'Name of the Faculty',
      field: 'name'
    },
    {
      name:'Name Of the Journal',
      field: 'description'
    }
  ];
  
  $scope.content = [
    {
      thumb:'https://i1.rgstatic.net/ii/profile.image/595236359262208-1518926815091_Q512/Anandakumar_Subbaiyyan.jpg',
      name: 'Dr.K.Sreenivasulu',
      description: 'Journal of Computational Biology and Bioinformatics Research',
    },{
      thumb:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS84w-P73SCCk444rSCMxSxkto1dpMy0br7MWMfvkbs_flS493jXQ&s',
      name: 'Dr. V. Praveen Kumar',
      description: 'African Journal of Plant Science',

    },
    {
      thumb:'https://i1.rgstatic.net/ii/profile.image/595236359262208-1518926815091_Q512/Anandakumar_Subbaiyyan.jpg',
      name: 'Dr.B.Mahendran',
      description: 'International journal of Genetics',
    }
  ];
  
  $scope.custom = {name: 'bold', description:'grey',publisher:'grey',year: 'grey'};
  $scope.sortable = ['name', 'description','publisher', 'year'];
  $scope.thumbs = 'thumb';
  $scope.count = 3;
}]);

app.directive('mdTable', function () {
  return {
    restrict: 'E',
    scope: { 
      headers: '=', 
      content: '=', 
      sortable: '=', 
      filters: '=',
      customClass: '=customClass',
      thumbs:'=', 
      count: '=' 
    },
    controller: function ($scope,$filter,$window) {
      var orderBy = $filter('orderBy');
      $scope.tablePage = 0;
      $scope.nbOfPages = function () {
        return Math.ceil($scope.content.length / $scope.count);
      },
      	$scope.handleSort = function (field) {
          if ($scope.sortable.indexOf(field) > -1) { return true; } else { return false; }
      };
      $scope.order = function(predicate, reverse) {
          $scope.content = orderBy($scope.content, predicate, reverse);
          $scope.predicate = predicate;
      };
      $scope.order($scope.sortable[0],false);
      $scope.getNumber = function (num) {
      			    return new Array(num);
      };
      $scope.goToPage = function (page) {
        $scope.tablePage = page;
      };
    },
    template: angular.element(document.querySelector('#md-table-template')).html()
  }
});

//UNCOMMENT BELOW TO BE ABLE TO RESIZE COLUMNS OF THE TABLE
/*
app.directive('mdColresize', function ($timeout) {
  return {
    restrict: 'A',
    link: function (scope, element, attrs) {
      scope.$evalAsync(function () {
        $timeout(function(){ $(element).colResizable({
          liveDrag: true,
          fixed: true
          
        });},100);
      });
    }
  }
});
*/

app.directive('showFocus', function($timeout) {
  return function(scope, element, attrs) {
    scope.$watch(attrs.showFocus, 
      function (newValue) { 
        $timeout(function() {
            newValue && element.focus();
        });
      },true);
  };    
});

app.filter('startFrom',function (){
  return function (input,start) {
    start = +start;
    return input.slice(start);
  }
});